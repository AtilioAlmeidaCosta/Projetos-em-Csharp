﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; //Biblioteca necessária para instanciar os Objetos Stream e File
using System.Runtime.CompilerServices;
using System.Xml.Linq;
using System.Reflection.Emit;
using System.Reflection;

namespace TP_arquivo_texto_html
{
    internal class Program
    {
        static void criarDiretorio (string caminho, string nomeDoArquivo, string conteudo)
        {
            //cria os dirtórios e arquivos
            Directory.CreateDirectory(caminho.Substring(0, 51));
            Path.Combine(caminho.Substring(0, 50), nomeDoArquivo);
            File.WriteAllText(caminho, conteudo);

            Console.Clear();


        }
        static void criarEstruturaHTML(StreamWriter inserirNoHtml, int posicaoNoHTML)
        {
            //Cria o HTML base, e separa a ciração em etapas
            switch (posicaoNoHTML)
            {
                case 0:
                    inserirNoHtml.WriteLine("<!DOCTYPE html>");
                    inserirNoHtml.WriteLine("<html lamg = \"pt-br\">");
  

                    inserirNoHtml.WriteLine("<head>");
                    inserirNoHtml.WriteLine("<style type = \"text/css\">");
                    inserirNoHtml.WriteLine("body{display:flex;flex-direction: column;  align-items: center;width:100%;}");
                    inserirNoHtml.WriteLine("header,main,footer{width:80%;}");
                    inserirNoHtml.WriteLine("</style>");
                    break;

                case 1:
                    inserirNoHtml.WriteLine("</head>");
                    inserirNoHtml.WriteLine("<header>");
                    break;

                case 2:
                    inserirNoHtml.WriteLine("</header>");
                    inserirNoHtml.WriteLine("<body>");
                    inserirNoHtml.WriteLine("<main>");
                    inserirNoHtml.WriteLine("<form method=\"get\">");
                    break;

                case 3:
                    inserirNoHtml.WriteLine("</form> ");
                    inserirNoHtml.WriteLine("</main>");
                    inserirNoHtml.WriteLine("</body>");
                    inserirNoHtml.WriteLine("<footer class=\"baixo\">");
                    break;
                case 4:
                    inserirNoHtml.WriteLine("</footer>");
                    inserirNoHtml.WriteLine("</html>");
                    break;

            }

        }

        static string traduzirPosicionamentoDaTag(string posicionamentoDaTag) {
            //É função que vai receber o posicionamento e retornar o estilo inline
            string estiloInline ="";

            switch (posicionamentoDaTag)
            {
                case "superior-esquerdo":
                    estiloInline = "position: flex; margin-top: 0; margin-left: 0;";
                    break;

                case "superior-centro":
                    estiloInline = "position: flex; margin-top: 0; margin-left: 20%;";
                    break;

                case "superior-direito":
                    estiloInline = "position: flex; margin-top: 0; margin-right: 0;";
                    break;

                case "centro-esquerdo":
                    estiloInline = "position: flex; margin-top: 50%; margin-left: 0; ";
                    break;

                case "centro-centro":
                    estiloInline = "position: flex; margin-top: 50%; margin-left: 20%; ";
                    break;

                case "centro-direito":
                    estiloInline = "position: flex; margin-top: 50%; margin-right: 0; ";
                    break;

                case "inferior-esquerdo":
                    estiloInline = "position: flex; margin-bottom: 0; margin-left: 0;";
                    break;

                case "inferior-centro":
                    estiloInline = "position: flex; margin-bottom: 0; margin-left: 20%; ";
                    break;

                case "inferior-direito":
                    estiloInline = "position: flex; margin-bottom: 0; margin-right: 0;";
                    break;

                default:
                    estiloInline = ""; // Caso o posicionamento não seja reconhecido, não será aplicado nenhum estilo
                    break;
            }
            return estiloInline;
            

//            posicionamentoDaTag = "";
//            return posicionamentoDaTag;
        }

        static int contadorDeOpcoes(string opcoes)
        {
            //Contador para as opções de muliplas escolhas
            int contador = 0;
            foreach (char temVirgula in opcoes)
            {
                if (temVirgula == ',')
                    contador++;
            }
            return contador;
        }


        static void tituloHTML(int i, string linha, StreamWriter inserirNoHtml)
        {
            string txtTitulo = linha.Substring(linha.IndexOf('^') + 1);
            txtTitulo = txtTitulo.Trim(new char[] { '&', '^' });
            inserirNoHtml.WriteLine($"<title>{txtTitulo}</title>");

        }


        static void botaoHtml(int i, string linha, StreamWriter inserirNoHtml)
        {
            string txtDoBotao = linha.Substring(linha.IndexOf('(') + 1, linha.IndexOf(')') - 1);
            string posicionamentoDaTag = linha.Substring(linha.IndexOf(')') + 1);
            posicionamentoDaTag = posicionamentoDaTag.Trim(new char[] { '&' });
            posicionamentoDaTag = traduzirPosicionamentoDaTag(posicionamentoDaTag);

            if (txtDoBotao == "Enviar")
            {
                inserirNoHtml.WriteLine($"<input style=\"{posicionamentoDaTag}\" type = \"submit\" value = \"{txtDoBotao}\">");
            }
            else
            {
                if (txtDoBotao == "Reset" | txtDoBotao == "Resetar")
                    inserirNoHtml.WriteLine($"<input style=\"{posicionamentoDaTag}\"  type = \"reset\" value = \"{txtDoBotao}\">");
                else
                    inserirNoHtml.WriteLine($"<input style=\"{posicionamentoDaTag}\"  type = \"button\" value = \"{txtDoBotao}\">");

            }



        }

        static void paragrafoHTML(int i, string linha, StreamWriter inserirNoHtml)
        {
            string txtDoParagrafo = linha.Substring(linha.IndexOf('{') + 1, linha.IndexOf('}') -1);
            string posicionamentoDaTag = linha.Substring(linha.IndexOf('}') + 1);
            posicionamentoDaTag = posicionamentoDaTag.Trim(new char[] { '&' });
            posicionamentoDaTag = traduzirPosicionamentoDaTag(posicionamentoDaTag);

            inserirNoHtml.WriteLine($"<p style=\"{posicionamentoDaTag}\">{txtDoParagrafo}</p>");
         
        }

        static void caixaDeTextoHtml(int i,string linha, StreamWriter inserirNoHtml, int idCaixaDeTexto)
        {
            string txtDaCaixaDeTexto = linha.Substring(linha.IndexOf('[') + 1 , linha.IndexOf(']')-1);
            string posicionamentoDaTag = linha.Substring(linha.IndexOf(']') + 1);
            posicionamentoDaTag = posicionamentoDaTag.Trim(new char[] { '&' });
            posicionamentoDaTag = traduzirPosicionamentoDaTag(posicionamentoDaTag);

            inserirNoHtml.WriteLine($"<div style=\"{posicionamentoDaTag}\">");

            inserirNoHtml.WriteLine($"<label for= \"caixaTxt{idCaixaDeTexto}\" style=\"{posicionamentoDaTag}\"> {txtDaCaixaDeTexto}</label>");
            inserirNoHtml.WriteLine($"<input id =\"caixaTxt{idCaixaDeTexto}\" type=\"text\">");

            inserirNoHtml.WriteLine("</div>");


        }


        static int radioButtonOuCheckBoxHtml(string linha, StreamWriter inserirNoHtml, int id, string tipoDaTag)
        {
            //Função responsavel pela criação dos elemntos de multipla escolha
            string titulo;
            string name = tipoDaTag + id;
            if (tipoDaTag == "radio")
            {
                titulo = linha.Substring(linha.IndexOf('@') + 1, linha.IndexOf(',') -1);
            }
            else
            {
                titulo = linha.Substring(linha.IndexOf('*') + 1, linha.IndexOf(',')-1);
            }

            string opcoesRestantes = linha.Substring(linha.IndexOf(',') + 1, linha.IndexOf(']') - linha.IndexOf(',') - 1);
            string posicionamentoDaTag = linha.Substring(linha.IndexOf(']') + 1);
            posicionamentoDaTag = posicionamentoDaTag.Trim(new char[] { '&' });

            posicionamentoDaTag = traduzirPosicionamentoDaTag(posicionamentoDaTag);


            inserirNoHtml.WriteLine($"<fieldset  style=\"{posicionamentoDaTag}\">");
            inserirNoHtml.WriteLine($"<legend>{titulo}</legend>");

            //Aqui ele pega a quantidade de opcoes(as opcoes são separadas por vigula, e o contador contará a qtd de virgulas).
            //Note que a quantidade de opcoes será igual a contador + 1 pois a ultima opcao não termina com virgula.
            int contador = contadorDeOpcoes(opcoesRestantes);

            //Aqui é definido um vetor que pegará as opções por ordem
            string[] opcoes = new string[contador];
            for (int i = 0; i < contador; i++)
            {
                //O vetor recebe as opcoes em ordem 
                opcoes[i] = opcoesRestantes.Substring(0, opcoesRestantes.IndexOf(','));
                //Aqui a variavel opcoesRestantes é atualizada retrirando a opcao que já foi restagada pelo vetor anterior
                opcoesRestantes = opcoesRestantes.Substring(opcoes[i].Length + 1);
                //Aqui o input é inserido em si. O id varia.
                inserirNoHtml.WriteLine($"<input type=\"{tipoDaTag}\" id=\"{tipoDaTag}{id}\" value=\"{opcoes[i]}\" name=\"{name}\" ><label for=\"{tipoDaTag}{id}\">{opcoes[i]}</label><br>");
                id++;
            }
            //Aqui é preciso inserir a ultima opcao fora do For porque ela não tem virgula no fim
            if (opcoesRestantes != null)
            {
                opcoesRestantes = opcoesRestantes.Trim(new char[] { ')', '&' });
                inserirNoHtml.WriteLine($"<input type=\"{tipoDaTag}\" id=\"{tipoDaTag}{id}\" value=\"{opcoesRestantes}\" name=\"{name}\" ><label for=\"radio{id}\">{opcoesRestantes}</label><br>");

            }
            inserirNoHtml.WriteLine("</fieldset>");


            return id++;
        }

        static int comboBoxHtml(string linha, StreamWriter inserirNoHtml, int idComboBox)
        {
            string titulo = linha.Substring(linha.IndexOf('#') + 1, linha.IndexOf(',') - 1);
            string opcoesRestantes = linha.Substring(linha.IndexOf(',') + 1, linha.IndexOf(']') - linha.IndexOf(',') - 1);
            string posicionamentoDaTag = linha.Substring(linha.IndexOf(']') + 1);
            posicionamentoDaTag = posicionamentoDaTag.Trim(new char[] { '&' });

            posicionamentoDaTag = traduzirPosicionamentoDaTag(posicionamentoDaTag);


            inserirNoHtml.WriteLine($"<fieldset  style=\"{posicionamentoDaTag}\">");
            inserirNoHtml.WriteLine($"<legend>{titulo}</legend>");
            inserirNoHtml.WriteLine($"<select id=\"select{idComboBox}\">");

            //Aqui ele pega a quantidade de opcoes(as opcoes são separadas por vigula, e o contador contará a qtd de virgulas).
            //Note que a quantidade de opcoes será igual a contador + 1 pois a ultima opcao não termina com virgula.
            int contador = contadorDeOpcoes(opcoesRestantes);

            //Aqui é definido um vetor que pegará as opções por ordem
            string[] opcoes = new string[contador];
            for (int i = 0; i < contador; i++)
            {
                //O vetor recebe as opcoes em ordem 
                opcoes[i] = opcoesRestantes.Substring(0, opcoesRestantes.IndexOf(','));
                //Aqui a variavel opcoesRestantes é atualizada retrirando a opcao que já foi restagada pelo vetor anterior
                opcoesRestantes = opcoesRestantes.Substring(opcoes[i].Length + 1);
                //Aqui o input é inserido em si. O id varia.
                inserirNoHtml.WriteLine($"<option value=\"{opcoes[i]}\">{opcoes[i]}</option>");
                idComboBox++;
            }
            //Aqui é preciso inserir a ultima opcao fora do For porque ela não tem virgula no fim
            if (opcoesRestantes != null)
            {
                opcoesRestantes = opcoesRestantes.Trim(new char[] { ')', '&' });
                inserirNoHtml.WriteLine($"<option value=\"{opcoesRestantes}\">{opcoesRestantes}</option>");
            }
            inserirNoHtml.WriteLine($"</select>");
            inserirNoHtml.WriteLine("</fieldset>");

            return idComboBox++;
        }

        static void Main(string[] args)
        {
            //Definição das variaveis
           
            string caminhoDoTxt = "C:/Atilio_Beatriz_Cesar_Joao/TP_arquivo_texto_html/texto.txt";
            string caminhoDoHtml = "C:/Atilio_Beatriz_Cesar_Joao/TP_arquivo_texto_html/index.html";
            StreamWriter escritor = null;
            StreamReader leitor = null;
            int op = 1;

            //Estrutura "try-catch" é usada para lidar com Erros de Execução. Se algo ocorrer, uma mensagem será mostrada com o Erro.
            try
            {
                //Laço de repetição principal.
                while (op == 1)
                {
                    Console.Clear();

                    FileInfo checarDiretorioTxt = new FileInfo(caminhoDoTxt);
                    FileInfo checarDiretorioHtml = new FileInfo(caminhoDoHtml);
                    //Condicional se existe ou não o diretório criado
                    if (checarDiretorioTxt.Exists && checarDiretorioHtml.Exists)
                    {
                        //definição dos elementos de edição
                        leitor = new StreamReader(caminhoDoTxt);
                        escritor = new StreamWriter(caminhoDoHtml);
                        string linha = "";
                        string separaDados;
                        int variaPosicao = 0;
                        int idCaixaDeTexto = 0; int idComboBox = 0; int idCheckBox = 0; int idRadio = 0;

                        criarEstruturaHTML(escritor, variaPosicao);

                        //Inicio da varredura das linhas
                        while ((linha = leitor.ReadLine()) != null)
                        {
                            Console.Write(linha);
                            int tam = linha.Length;
                             //Inicio da checagem e implementação dos elementos html   
                            for (int i = 0; i < tam; i++)
                            {
                                separaDados = linha.Substring(i, 1);
                                switch (separaDados)
                                {
                                    case "^":
                                        tituloHTML(i, linha, escritor);
                                        break;
                                    case "&":
                                        variaPosicao++;
                                        criarEstruturaHTML(escritor, variaPosicao);
                                        break;

                                    case "{":
                                        //paragrafo
                                        paragrafoHTML(i, linha, escritor);
                                        break;

                                    case "(":
                                        //botao
                                        botaoHtml(i, linha, escritor);
                                        break;

                                    case "[":
                                        //caixa de texto
                                        caixaDeTextoHtml(i, linha, escritor, idCaixaDeTexto);
                                        idCaixaDeTexto++;
                                        break;

                                    case "*":
                                        //checkbox
                                        idCheckBox = radioButtonOuCheckBoxHtml(linha, escritor, idCheckBox, "checkbox");
                                        break;

                                    case "@":
                                        //radiobutton
                                        idRadio = radioButtonOuCheckBoxHtml(linha, escritor, idRadio, "radio");
                                        break;

                                    case "#":
                                        //combobox
                                        idComboBox= comboBoxHtml(linha, escritor, idComboBox);
                                        break;


                                }
                            }
                        }

                        op = 0;

                        leitor.Close();
                        escritor.Close();
                    }
                    else
                    {
                        //Se não existir os diretórios ele cria aqui em baixo
                        criarDiretorio(caminhoDoTxt, "texto.txt", "");
                        criarDiretorio(caminhoDoHtml, "index.html", "");
                        
                        string caminhoDaInstrucao = "C:/Atilio_Beatriz_Cesar_Joao/TP_arquivo_texto_html/instruções.txt";
                        criarDiretorio(caminhoDaInstrucao, "instruções.txt", "^ título\r\n( ) botao\r\n[texto] caixa de texto\r\n{ } paragrafos\r\n*Título do Checkbox, opcao1, opcao2, opcao3]checkBox\r\n@Título do Radibutton, opcao1, opcao2, opcao] radiobutton\r\n#Título do Combobox, opcao1, opcao2, opcao3] combobox \r\n& fim do campo do html(Começa em: <head> <title>, <body> <header>, <body> <main> <form>, <footer>). \r\n\r\nÉ preciso colocar a posição do elemento logo após, assim:\r\n\r\n(Enviar)inferior-centro\r\n[Nome]esquerda-centro\r\n*Cores Favoritas, branca, preta, amarela, laranja, vermelha]superior-direito\r\n\r\nValores válidos para posicionamento: \r\n\r\nsuperior-esquerdo\r\nsuperior-centro\r\nsuperior-direito\r\n\r\ncentro-esquerdo\r\ncentro-centro\r\ncentro-direito\r\n\r\ninferior-esquerdo\r\ninferior-centro\r\ninferior-direito\r\n\r\nO arquivo de texto começará assim \r\n\r\n<html>\r\n\r\n\t<head>\r\n\t\t<title>Começará aqui até colocar o \"&\"</title>\r\n\t</head>\r\n\r\n\t<body>\r\n\t\t<header>\r\n\t\t\tContinuará aqui até colocar o \"&\"\r\n\t\t</header>\r\n\t\t<main>\r\n\t\t\t<form>\r\n\t\t\t\tPassará para cá e ficará até colocar o \"&\"\r\n\t\t\t</form>\r\n\t\t</main>\t\r\n\t</body>\r\n\r\n\t<footer>\r\n\t\tPassará para cá.\r\n\t</footer>\r\n\r\n</html>\r\n\r\n\r\nExemplo:\r\n\r\n^Trabalho Prático C&\r\n[Essa é o header]centro-centro&\r\n[Essa é a main]superior-centro\r\n@Cor Favorita,Vermelha,Azul,Preta,Branca,Outra]centro-esquerdo\r\n(Enviar)inferior-centro&\r\n[Esse é o Footer]centro-centro&\r\n\r\nResultado: \r\n\r\n<html>\r\n\r\n\t<head>\r\n\t\t<title>Trabalho Prático C#</title>\r\n\t</head>\r\n\r\n\t<body>\r\n\t\t<header>\r\n\t\t\t<div style=\"\">\r\n\t\t\t\t<label for=\"inputHeader\">Essa é o header:</label>\r\n\t\t\t\t<input name=\"inputHeader\" type=\"text\" >\r\n\t\t\t</div>\r\n\t\t</header>\r\n\t\t<main>\r\n\t\t\t<div style=\"\">\r\n\t\t\t\t<label for=\"inputMain\">Essa é a main:</label>\r\n\t\t\t\t<input name=\"inputMain\" type=\"text\">\r\n\t\t\t</div>\r\n\r\n\t\t\t<div style=\"\">\r\n\t\t\t\t<p>Cor Favorita:</p>\r\n\t\t\t\t<input type=\"radio\" id=\"inputVermelha\" value=\"Vermelha\">\r\n  \t\t\t\t<label for=\"inputVermelha\">Vermelha</label><br>\r\n\r\n\t\t\t\t<input type=\"radio\" id=\"inputAzul\" value=\"Azul\">\r\n  \t\t\t\t<label for=\"inputAzul\">Azul</label><br>\r\n\r\n\t\t\t\t<input type=\"radio\" id=\"inputPreta\" value=\"Preta\">\r\n  \t\t\t\t<label for=\"inputPreta\">Preta</label><br>\r\n\r\n\t\t\t\t<input type=\"radio\" id=\"inputBranca\" value=\"Branca\">\r\n  \t\t\t\t<label for=\"inputBranca\">Branca</label><br>\r\n\r\n\t\t\t\t<input type=\"radio\" id=\"inputOutra\" value=\"Outra\">\r\n  \t\t\t\t<label for=\"inputOutra\">Outra</label><br>\r\n\r\n  \t\t\t\t\r\n\t\t\t</div>\r\n\t\t\t\r\n\t\t\t<div style=\"\">\r\n\t\t\t\t<button type=\"submit\">Enviar</button>\r\n\t\t\t</div>\r\n\t\t\t\r\n\r\n\t\t</main>\t\r\n\r\n\t</body>\r\n\r\n\t<footer>\r\n\t\t<div style=\"\">\r\n\t\t\t<label for=\"inputFooter\">Esse é o Footer:</label>\r\n\t\t\t<input name=\"inputFooter\" type=\"text\">\r\n\t\t</div>\r\n\t</footer>\r\n\r\n</html>\r\n\r\n\r\n");
                        
                        
                        Console.WriteLine("IMPORTANTE! Antes de Continuar a Execução, por gentileza, escrever as instruções no arquivo criado 'teste.txt'  no caminho: C:/Atilio_Beatriz_Cesar_Joao/TP_arquivo_texto_html/teste.txt");
                        Console.WriteLine("\n\nDeseja continuar a execução?  0- Não  1 - Sim\n");
                        Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep();
                        op = int.Parse(Console.ReadLine()); 
                     


                    }

                }


            }
            catch(Exception erro) 
            {
                //Aqui o erro é capturado e armazenado na variavel "erro" e posteriormente mostrado.
                Console.WriteLine(erro.Message);
            }
            finally
            {
                //Após o usuário encerrar ou se algum erro for encontrado, essa mensagem será exbida.
                Console.WriteLine("\n\n\nFIM DA EXECUÇÃO!");
                Console.WriteLine("\nPrecione 'Enter' para sair.");
                Console.ReadKey();
            }
            
        }
    }
}
